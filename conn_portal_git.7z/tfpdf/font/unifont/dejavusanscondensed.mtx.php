<?php
$name='DejaVuSansCondensed';
$type='TTF';
$desc=array (
  'Ascent' => 928,
  'Descent' => -236,
  'CapHeight' => 928,
  'Flags' => 4,
  'FontBBox' => '[-918 -463 1614 1232]',
  'ItalicAngle' => 0,
  'StemV' => 87,
  'MissingWidth' => 540,
);
$up=-63;
$ut=44;
$ttffile='D:\Programs\xampp\htdocs\tfpdf/font/unifont/DejaVuSansCondensed.ttf';
$originalsize=680264;
$fontkey='dejavu';
?>