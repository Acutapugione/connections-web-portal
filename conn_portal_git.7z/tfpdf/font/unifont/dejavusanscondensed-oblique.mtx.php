<?php
$name='DejaVuSansCondensed-Oblique';
$type='TTF';
$desc=array (
  'Ascent' => 928,
  'Descent' => -236,
  'CapHeight' => 928,
  'Flags' => 68,
  'FontBBox' => '[-914 -350 1493 1068]',
  'ItalicAngle' => -11,
  'StemV' => 87,
  'MissingWidth' => 540,
);
$up=-63;
$ut=44;
$ttffile='D:\Programs\xampp\htdocs\tfpdf/font/unifont/DejaVuSansCondensed-Oblique.ttf';
$originalsize=599292;
$fontkey='dejavu-obliqueU';
?>