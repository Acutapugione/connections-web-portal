<?php
$name='DejaVuSans';
$type='TTF';
$desc=array (
  'Ascent' => 928,
  'Descent' => -236,
  'CapHeight' => 928,
  'Flags' => 4,
  'FontBBox' => '[-1021 -463 1793 1232]',
  'ItalicAngle' => 0,
  'StemV' => 87,
  'MissingWidth' => 600,
);
$up=-63;
$ut=44;
$ttffile='D:\Programs\xampp\htdocs\tfpdf/font/unifont/DejaVuSans.ttf';
$originalsize=757076;
$fontkey='dejavu';
?>