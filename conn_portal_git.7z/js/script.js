$(".info-item .btnbox").click(function(){
  $(".containerbox").toggleClass("log-in");
});
$(".containerbox-form .btnbox").click(function(){
  $(".containerbox").addClass("active");
});